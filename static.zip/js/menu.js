var MenuImg, MobileNav, xBTN;

MenuImg = document.getElementById("menuBtn");
MobileNav = document.getElementById("MobileNav-left");

function MobileNavShow() {
    MobileNav.style.display = "flex";
};

function MobileNavHide() {
    MobileNav.style.display = "none";
};


